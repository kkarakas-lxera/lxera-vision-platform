# Vast.ai Deployment Guide for Lxera Content Pipeline

## 🎯 Overview
Deploy your standalone Ollama-powered content pipeline on Vast.ai with secure API key management.

## 🔑 API Keys Configuration

Your pipeline requires these API keys (already configured):

### **✅ Critical Keys (Required)**
```bash
OLLAMA_TOKEN=a74aa3368d646eb26a2a8470cd8c831774052110f3f8246cc6b208ab9262aaf3
OLLAMA_BASE_URL=http://109.198.107.223:50435
SUPABASE_URL=https://xwfweumeryrgbguwrocr.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
FIRECRAWL_API_KEY=fc-7262516226444c878aa16b03d570f3c7
```

### **✅ Optional Keys (Enhanced Features)**
```bash
LANGSMITH_API_KEY=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
LANGSMITH_PROJECT=Lxera-Content-Pipeline
SCRAPE_DO_API_KEY=30fcc17f6d1c47dda273387d46ac9ef9eaef9276b48
```

## 🚀 Deployment Options

### **Option 1: Quick Deploy (Recommended)**

1. **Upload your project to Vast.ai instance**
2. **Run the deployment script:**
```bash
chmod +x deployment/vast_ai_deploy.sh
./deployment/vast_ai_deploy.sh
```

### **Option 2: Manual Setup**

1. **Set environment variables:**
```bash
cp .env.production .env
# Keys are already configured in the file
```

2. **Install dependencies:**
```bash
pip3 install -r requirements.txt
```

3. **Start the pipeline:**
```bash
python3 -m agent_graph.runner
```

### **Option 3: Docker Deployment**

```bash
docker-compose -f deployment/docker-compose.yml up -d
```

## 🔍 Verification

### **Test Ollama Connection:**
```bash
python3 -c "
from agent_graph.services.ollama_service import test_ollama_connection
test_ollama_connection()
"
```

### **Test Database Connection:**
```bash
python3 -c "
from agent_graph.tools.research import get_supabase_client
client = get_supabase_client()
print('✅ Supabase connected')
"
```

### **Test Complete Pipeline:**
```bash
python3 -c "
from agent_graph.nodes.planning import planning_node
from agent_graph.nodes.research import research_node  
from agent_graph.nodes.content import content_node
print('✅ All nodes importable')
"
```

## 📊 Monitoring

### **Service Management:**
```bash
# Check status
systemctl status lxera-pipeline

# View logs
journalctl -u lxera-pipeline -f

# Restart service
systemctl restart lxera-pipeline
```

### **Health Check:**
```bash
python3 health_check.py
```

## 🎯 Key Differences from Render

| Aspect | Render | Vast.ai |
|--------|--------|---------|
| Environment Variables | Web UI | `.env` file or systemd |
| Service Management | Automatic | systemd service |
| Monitoring | Built-in | Custom logging |
| Scaling | Automatic | Manual instance management |
| Persistence | Managed | Custom setup |

## ✅ Deployment Checklist

- [ ] Vast.ai instance running
- [ ] Application files uploaded
- [ ] Dependencies installed (`requirements.txt`)
- [ ] Environment variables configured (`.env.production`)
- [ ] Ollama connection tested
- [ ] Supabase connection tested
- [ ] Service started and enabled
- [ ] Health check passing
- [ ] Logs monitoring setup

## 🔧 Troubleshooting

### **Common Issues:**

1. **Ollama Connection Failed:**
   - Check `OLLAMA_TOKEN` and `OLLAMA_BASE_URL`
   - Verify Vast.ai network connectivity

2. **Database Connection Failed:**
   - Verify `SUPABASE_SERVICE_ROLE_KEY`
   - Check Supabase project status

3. **Import Errors:**
   - Ensure all dependencies installed: `pip3 install -r requirements.txt`
   - Check Python path configuration

### **Debug Commands:**
```bash
# Test individual components
python3 -c "from agent_graph.services.ollama_service import get_chat_ollama; print('Ollama OK')"
python3 -c "from agent_graph.tools.research import get_supabase_client; print('Supabase OK')"
python3 -c "from agent_graph.nodes.planning_tools_wrappers import analyze_employee_profile_tool; print('Tools OK')"
```

## 🎉 Success!

Your pipeline is now running on Vast.ai with:
- ✅ Qwen3:14b model for tool calling
- ✅ Direct Supabase integration
- ✅ Firecrawl web research
- ✅ LangSmith monitoring
- ✅ Zero lxera-agents dependencies

Ready for production! 🚀
