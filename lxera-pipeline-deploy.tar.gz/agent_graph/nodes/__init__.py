"""Graph nodes (planning, research, content) – stubs only."""


