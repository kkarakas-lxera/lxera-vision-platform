"""API-layer helpers for integrating the agent graph into the Render service."""


