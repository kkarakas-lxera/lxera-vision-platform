"""Standalone tools for LangGraph agent pipeline - no external dependencies."""
